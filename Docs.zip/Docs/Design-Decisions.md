# Design Decisions & Architecture Decision Records (ADRs)
**Project:** Words We Never Said (WWNS)  
**Engine:** Unreal Engine 5 (Hybrid C++ & Blueprints)  
**Team Size:** 3 Developers  

This document tracks foundational **Technical Decisions** and **Gameplay Systems Decisions** required to prevent production roadblocks, scope creep, and Git conflicts.

---

## Part 1: Resolved Core Decisions (Summary)

The following architectural decisions have been established in `05-Architecture-Design.md`:

| ID | Topic | Decision | Rationale |
| :--- | :--- | :--- | :--- |
| **ADR-01** | **Code Structure** | Hybrid C++ base classes + Blueprint extensions. | C++ ensures high performance, clean interfaces, and low memory coupling; Blueprints allow rapid designer iteration. |
| **ADR-02** | **State Management** | `UGameInstanceSubsystem` instead of monolithic `GameInstance`. | Separates Story Progression, Memory Tracking, and Save Coordination into modular, self-contained lifecycles. |
| **ADR-03** | **Memory Optimization** | Soft Object References (`TSoftObjectPtr`) for audio/VFX in Data Assets. | Prevents loading high-resolution audio and Niagara VFX across all 5 levels into RAM prematurely. |
| **ADR-04** | **Input Architecture** | UE5 Enhanced Input Subsystem (`UInputMappingContext`). | Modularly swaps input states (`IMC_Default`, `IMC_Inspection`, `IMC_Puzzle`) via context priorities instead of boolean tick checks. |
| **ADR-05** | **Level Collaboration** | One File Per Actor (OFPA) / World Partition enabled for master levels. | Serializes actors into individual external files (`__ExternalActors__`), allowing 3 developers to populate levels simultaneously without `.umap` merge conflicts. |
| **ADR-06** | **Save System** | `USaveCoordinationSubsystem` + `UWWNS_SaveGame` via `AsyncSaveGameToSlot`. | Asynchronously gathers state from progression subsystems without blocking the game thread. |

---

## Part 2: Open Technical Decisions (Need Resolution)

### 1. Player Character Camera & Body Rig
* **Problem:** How should the protagonist be represented visually to the player?
* **Option A: Arms-Only / Floating Camera (Classic FPV Adventure)**
  * *Pros:* Zero camera clipping into character body mesh, simplest animation workload, fast to implement.
  * *Cons:* No dynamic body shadows cast on ground; lower physical immersion.
* **Option B: True First-Person (Full Body Mesh with Camera at Head Socket)**
  * *Pros:* Realistic shadows and self-presence when looking down.
  * *Cons:* Requires complex head-bob stabilization, IK tuning, and clipping prevention when near walls or inspecting objects.
* **Recommendation:** **Option A (Arms-Only / Floating Camera)** with simple shadow proxy mesh. Narrative psychological games like *What Remains of Edith Finch* and *Layers of Fear* prioritize camera stability and zero clipping over full-body IK.

---

### 2. 3D Object Inspection Pipeline
* **Problem:** When the player picks up an object to examine it in 3D, how is it rendered?
* **Option A: In-World Camera Socket Attachment**
  * The object is moved and attached to a socket in front of the player's camera.
  * *Pros:* Retains the level's dynamic lighting and mood.
  * *Cons:* High risk of clipping into walls, furniture, or doorframes if the player inspects objects in tight spaces.
* **Option B: Dedicated Inspection 3D Viewport / Render Target Scene**
  * The object is temporarily hidden in-world and spawned into a separate isolated inspection studio room (or Render Target), with depth and lighting controlled independently.
  * *Pros:* Guaranteed zero environment clipping, pristine studio lighting, seamless rotation without physical collisions.
  * *Cons:* Requires a separate UI 3D viewport setup or background blur layer.
* **Recommendation:** **Option B** (or in-world attachment with temporary collision disabling and wall pullback detection).

---

### 3. Level 4 Perspective Switching (Husband, Wife, Child)
* **Problem:** Level 4 requires playing through or witnessing three distinct perspectives. How is this handled in code?
* **Option A: Three Distinct Pawn Classes**
  * Possessing different Character blueprints (`BP_Player_Husband`, `BP_Player_Wife`, `BP_Player_Child`) via `PlayerController->Possess()`.
  * *Pros:* Completely clean separation of height, walk speed, audio footsteps, and specific components.
  * *Cons:* Harder to maintain state continuity across transitions.
* **Option B: Single Character with Dynamic Profile Struct**
  * The same `AWWNS_PlayerCharacter` swaps height, camera offset, walk speed, and post-process effects dynamically via a `FCharacterPerspectiveProfile` Data Asset.
  * *Pros:* Shared interaction components, no possession glitches or controller re-initialization.
  * *Cons:* Character class holds configuration logic for all three profiles.
* **Recommendation:** **Option B** if interactions are identical; **Option A** if height, animations, and movement mechanics differ significantly.

---

### 4. Audio Framework & Tension Implementation
* **Problem:** How will Emotional Pressure drive dynamic audio distortion and heartbeat escalation?
* **Option A: Traditional Sound Cues**
  * Basic crossfading and pitch shifting via Blueprint parameters.
  * *Pros:* Simple to learn.
  * *Cons:* Limited procedural audio capability; difficult to create dynamic tinnitus/distortion filters.
* **Option B: UE5 MetaSounds**
  * Next-gen procedural audio system in UE5 with real-time DSP, parameters, and filters.
  * *Pros:* Can directly modulate low-pass filters, heartbeat tempo, and binaural distortion in real time using the `Pressure` float (0-100).
  * *Cons:* Slight learning curve for sound designer.
* **Recommendation:** **Option B (MetaSounds)** for the Pressure/Heartbeat/Ambience system, standard Sound Waves/Cues for dialogue.

---

### 5. Dialogue & Subtitle Architecture
* **Problem:** How are voice lines, subtitles, and localization structured?
* **Option A: Hardcoded Strings in Data Assets**
  * Typing text directly in `DA_MemoryEcho`.
  * *Pros:* Fast for quick prototypes.
  * *Cons:* Impossible to localize into other languages; text changes require opening individual assets.
* **Option B: Unreal Engine String Tables (`UStringTable`)**
  * Centralized CSV/String Tables referenced by key in Data Assets (`ST_Dialogue`, `ST_Subtitles`).
  * *Pros:* Industry standard, easily exported to Excel/Google Sheets for writers, instant localization readiness.
* **Recommendation:** **Option B (String Tables)**.

---

## Part 3: Open Gameplay & System Decisions (Need Resolution)

### 1. Emotional Pressure Failure State ("Collapse")
* **Problem:** What happens when Emotional Pressure reaches 100%?
* **Option A: Hard Failure (Death / Reload)**
  * Player faints, screen fades to black, audio flatlines, and game reloads last checkpoint.
  * *Risk:* Can cause frustration and break narrative pacing in an emotional story.
* **Option B: Soft Breakdown (Hallucinatory Reset)**
  * The player suffers an emotional breakdown: severe visual distortion, audio disorientation, memory echo failure. The player stumbles and recovers at the entrance of the current memory/room with Pressure reset to 40-50%, losing no narrative progress.
  * *Pros:* Maintains psychological tension without punishing the player like an action game.
* **Recommendation:** **Option B (Soft Breakdown)**.

---

### 2. Emotional Pressure Recovery Mechanics
* **Problem:** How does the player reduce pressure?
* **Option A: Passive Decay in Safe Zones**
  * Pressure automatically ticks down when standing in well-lit areas or rooms free of memories.
* **Option B: Active Coping Actions**
  * Interacting with grounding objects (e.g., holding a comforting photo, sitting on a bench, breathing exercise).
* **Option C: Narrative Resolution Only**
  * Pressure only decreases when successfully solving a sentence puzzle, reconstructing a memory, or making an honest emotional choice.
* **Recommendation:** Combination of **Option B (Grounding Objects)** and **Option C (Puzzle Resolution)**. Avoid passive decay to keep tension meaningful.

---

### 3. Sentence Puzzle Retry & Hint System
* **Problem:** What happens if the player constructs the wrong sentence order?
* **Decisions Needed:**
  1. *Pressure Penalty:* Does each failed attempt add pressure (e.g., +10 Pressure)?
  2. *Feedback:* Does the game reject the whole sentence or highlight which word fragments are in the wrong positions?
  3. *Hint System:* After 3 failed attempts, should a subtle audio whisper or highlighted fragment provide a hint to prevent player blockages?

---

### 4. Player Locomotion Constraints
* **Problem:** What movement mechanics are permitted?
  * **Sprint:** Can the player run? (Recommendation: No sprint, or only a light brisk walk. Running breaks the pacing of narrative exploration and triggers).
  * **Crouch:** Is crouching needed for puzzles or navigation?
  * **Head Bob / Camera Shake:** Should there be toggleable accessibility settings for motion sickness?

---

### 5. Interaction Visual Feedback (Diegetic vs. UI)
* **Problem:** How does the player know an object is interactable?
* **Option A: Center Crosshair / Dot**
  * Reticle changes icon (dot -> hand / eye icon).
* **Option B: Custom Depth Stencil Outline**
  * The 3D object glows with a subtle outline shader when looked at.
* **Option C: Diegetic Lighting / Proximity Glint**
  * Subtle glint on the object when nearby; interaction prompt only appears when within reach.
* **Recommendation:** **Option A + Option B** (Center dot that expands, with subtle custom depth outline on hover).

---

## Part 4: Production & Git Collaboration Decisions

### 1. Git LFS Configuration
* Unreal binary formats that **must** be tracked in `.gitattributes` under Git LFS:
  * `*.uasset`, `*.umap`
  * `*.fbx`, `*.obj`
  * `*.wav`, `*.mp3`, `*.ogg`
  * `*.png`, `*.tga`, `*.exr`, `*.psd`
  * `*.mp4`, `*.bk2`

### 2. Team Asset Ownership & Assignment
To prevent merge conflicts, each team member should have primary ownership over specific domains:
* **Developer 1 (Rana):** Core Framework (C++), Subsystems, Interaction System, Enhanced Input, Save System.
* **Developer 2 (Story & Levels):** Level Dressing (OFPA), Trigger Placement, Level Sequencer Cinematics, Lighting.
* **Developer 3 (Audio, VFX & UI):** MetaSounds, Niagara Systems, UI Widgets (HUD, Inspection, Puzzle Screens), Data Asset Configuration.
